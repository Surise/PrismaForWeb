// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `Моля, съответствайте на изискания формат.`,
    'functions.alert.confirmText': `ОК`,
    'functions.confirm.cancelText': `Отказ`,
    'functions.confirm.confirmText': `ОК`,
    'functions.prompt.cancelText': `Отказ`,
    'functions.prompt.confirmText': `ОК`,
};
