// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `Будь ласка, відповідайте вимогам формату.`,
    'functions.alert.confirmText': `ОК`,
    'functions.confirm.cancelText': `Скасувати`,
    'functions.confirm.confirmText': `ОК`,
    'functions.prompt.cancelText': `Скасувати`,
    'functions.prompt.confirmText': `ОК`,
};
