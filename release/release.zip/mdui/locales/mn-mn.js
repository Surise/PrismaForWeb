// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `Та хүссэн загвартай тааруулж байхаар оруулна уу.`,
    'functions.alert.confirmText': `Зөв`,
    'functions.confirm.cancelText': `Цуцлах`,
    'functions.confirm.confirmText': `Зөв`,
    'functions.prompt.cancelText': `Цуцлах`,
    'functions.prompt.confirmText': `Зөв`,
};
