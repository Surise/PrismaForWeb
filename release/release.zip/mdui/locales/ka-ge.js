// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `გთხოვთ, შეიყვანოთ მოთხოვნილი ფორმატი.`,
    'functions.alert.confirmText': `კარგი`,
    'functions.confirm.cancelText': `გაუქმება`,
    'functions.confirm.confirmText': `კარგი`,
    'functions.prompt.cancelText': `გაუქმება`,
    'functions.prompt.confirmText': `კარგი`,
};
