// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `សូមផ្គូផ្គងទៅនឹងទ្រង់ទ្រាយដែលបានស្នើរ។`,
    'functions.alert.confirmText': `យល់ព្រម`,
    'functions.confirm.cancelText': `បោះបង់`,
    'functions.confirm.confirmText': `យល់ព្រម`,
    'functions.prompt.cancelText': `បោះបង់`,
    'functions.prompt.confirmText': `យល់ព្រម`,
};
