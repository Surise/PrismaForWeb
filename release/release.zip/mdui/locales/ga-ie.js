// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `Tabhair aghaidh ar an bhformáid a iarradh, le do thoil.`,
    'functions.alert.confirmText': `OK`,
    'functions.confirm.cancelText': `Cealaigh`,
    'functions.confirm.confirmText': `OK`,
    'functions.prompt.cancelText': `Cealaigh`,
    'functions.prompt.confirmText': `OK`,
};
