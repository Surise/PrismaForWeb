// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `要求された形式と一致させてください。`,
    'functions.alert.confirmText': `OK`,
    'functions.confirm.cancelText': `キャンセル`,
    'functions.confirm.confirmText': `OK`,
    'functions.prompt.cancelText': `キャンセル`,
    'functions.prompt.confirmText': `OK`,
};
