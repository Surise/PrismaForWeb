// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `โปรดตรงตามรูปแบบที่ร้องขอ`,
    'functions.alert.confirmText': `ตกลง`,
    'functions.confirm.cancelText': `ยกเลิก`,
    'functions.confirm.confirmText': `ตกลง`,
    'functions.prompt.cancelText': `ยกเลิก`,
    'functions.prompt.confirmText': `ตกลง`,
};
