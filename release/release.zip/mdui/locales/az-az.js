// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `Zəhmət olmasa, tələb olunan formatla uyğun gəlin.`,
    'functions.alert.confirmText': `Oldu`,
    'functions.confirm.cancelText': `Ləğv et`,
    'functions.confirm.confirmText': `Oldu`,
    'functions.prompt.cancelText': `Ləğv et`,
    'functions.prompt.confirmText': `Oldu`,
};
