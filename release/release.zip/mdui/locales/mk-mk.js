// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `Ве молиме, внесете го бараниот формат.`,
    'functions.alert.confirmText': `Во ред`,
    'functions.confirm.cancelText': `Откажи`,
    'functions.confirm.confirmText': `Во ред`,
    'functions.prompt.cancelText': `Откажи`,
    'functions.prompt.confirmText': `Во ред`,
};
