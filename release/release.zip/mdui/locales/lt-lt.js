// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `Prašome atitikti prašomą formatą.`,
    'functions.alert.confirmText': `Gerai`,
    'functions.confirm.cancelText': `Atšaukti`,
    'functions.confirm.confirmText': `Gerai`,
    'functions.prompt.cancelText': `Atšaukti`,
    'functions.prompt.confirmText': `Gerai`,
};
