export declare const templates: {
    'components.textField.patternError': string;
    'functions.alert.confirmText': string;
    'functions.confirm.cancelText': string;
    'functions.confirm.confirmText': string;
    'functions.prompt.cancelText': string;
    'functions.prompt.confirmText': string;
};
