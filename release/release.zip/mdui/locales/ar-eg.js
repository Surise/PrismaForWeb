// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `يرجى تطابق التنسيق المطلوب.`,
    'functions.alert.confirmText': `حسنًا`,
    'functions.confirm.cancelText': `إلغاء`,
    'functions.confirm.confirmText': `حسنًا`,
    'functions.prompt.cancelText': `إلغاء`,
    'functions.prompt.confirmText': `حسنًا`,
};
