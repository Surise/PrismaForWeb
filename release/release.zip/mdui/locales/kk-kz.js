// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `Сұрақтың талап еткен пішіні тексеріңіз.`,
    'functions.alert.confirmText': `Жақсы`,
    'functions.confirm.cancelText': `Болдырмау`,
    'functions.confirm.confirmText': `Жақсы`,
    'functions.prompt.cancelText': `Болдырмау`,
    'functions.prompt.confirmText': `Жақсы`,
};
