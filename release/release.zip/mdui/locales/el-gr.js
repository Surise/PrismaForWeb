// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `Παρακαλώ ταιριάστε με το απαιτούμενο μορφότυπο.`,
    'functions.alert.confirmText': `Εντάξει`,
    'functions.confirm.cancelText': `Ακύρωση`,
    'functions.confirm.confirmText': `Εντάξει`,
    'functions.prompt.cancelText': `Ακύρωση`,
    'functions.prompt.confirmText': `Εντάξει`,
};
