// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `Lūdzu, atbilstiet pieprasītajam formātam.`,
    'functions.alert.confirmText': `Labi`,
    'functions.confirm.cancelText': `Atcelt`,
    'functions.confirm.confirmText': `Labi`,
    'functions.prompt.cancelText': `Atcelt`,
    'functions.prompt.confirmText': `Labi`,
};
