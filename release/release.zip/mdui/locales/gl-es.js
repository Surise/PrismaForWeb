// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `Por favor, concorda co formato solicitado.`,
    'functions.alert.confirmText': `Aceptar`,
    'functions.confirm.cancelText': `Cancelar`,
    'functions.confirm.confirmText': `Aceptar`,
    'functions.prompt.cancelText': `Cancelar`,
    'functions.prompt.confirmText': `Aceptar`,
};
