// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `אנא התאים לפורמט המבוקש.`,
    'functions.alert.confirmText': `אישור`,
    'functions.confirm.cancelText': `ביטול`,
    'functions.confirm.confirmText': `אישור`,
    'functions.prompt.cancelText': `ביטול`,
    'functions.prompt.confirmText': `אישור`,
};
