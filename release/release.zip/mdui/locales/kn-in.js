// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `ಕೋರಿದ ನಮೂನೆಯನ್ನು ಹೊಂದಿಸಿ.`,
    'functions.alert.confirmText': `ಸರಿ`,
    'functions.confirm.cancelText': `ರದ್ದು ಮಾಡು`,
    'functions.confirm.confirmText': `ಸರಿ`,
    'functions.prompt.cancelText': `ರದ್ದು ಮಾಡು`,
    'functions.prompt.confirmText': `ಸರಿ`,
};
