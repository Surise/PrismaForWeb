// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `Խնդրում ենք համապատասխանեք հայցվող ձևաչափին։`,
    'functions.alert.confirmText': `Լավ`,
    'functions.confirm.cancelText': `Չեղարկել`,
    'functions.confirm.confirmText': `Լավ`,
    'functions.prompt.cancelText': `Չեղարկել`,
    'functions.prompt.confirmText': `Լավ`,
};
