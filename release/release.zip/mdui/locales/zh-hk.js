// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `請符合要求的格式。`,
    'functions.alert.confirmText': `確定`,
    'functions.confirm.cancelText': `取消`,
    'functions.confirm.confirmText': `確定`,
    'functions.prompt.cancelText': `取消`,
    'functions.prompt.confirmText': `確定`,
};
