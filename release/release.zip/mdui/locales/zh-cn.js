// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `请与所请求的格式保持一致。`,
    'functions.alert.confirmText': `确定`,
    'functions.confirm.cancelText': `取消`,
    'functions.confirm.confirmText': `确定`,
    'functions.prompt.cancelText': `取消`,
    'functions.prompt.confirmText': `确定`,
};
