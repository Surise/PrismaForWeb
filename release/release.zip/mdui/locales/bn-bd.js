// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `অনুগ্রহ করে অনুরোধিত ফরম্যাটের মেল দেওয়া হবে।`,
    'functions.alert.confirmText': `ঠিক আছে`,
    'functions.confirm.cancelText': `বাতিল করুন`,
    'functions.confirm.confirmText': `ঠিক আছে`,
    'functions.prompt.cancelText': `বাতিল করুন`,
    'functions.prompt.confirmText': `ঠিক আছে`,
};
