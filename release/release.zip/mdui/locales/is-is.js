// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `Vinsamlegast samsvarið við beiðni um snið.`,
    'functions.alert.confirmText': `Í lagi`,
    'functions.confirm.cancelText': `Hætta við`,
    'functions.confirm.confirmText': `Í lagi`,
    'functions.prompt.cancelText': `Hætta við`,
    'functions.prompt.confirmText': `Í lagi`,
};
