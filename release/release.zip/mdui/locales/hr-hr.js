// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `Molimo podudarajte se s traženim formatom.`,
    'functions.alert.confirmText': `U redu`,
    'functions.confirm.cancelText': `Odustani`,
    'functions.confirm.confirmText': `U redu`,
    'functions.prompt.cancelText': `Odustani`,
    'functions.prompt.confirmText': `U redu`,
};
