// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `தயவுசெய்து கேள்விக்கான வடிவமைப்பு பொருத்தமாக உள்ளது.`,
    'functions.alert.confirmText': `சரி`,
    'functions.confirm.cancelText': `ரத்து`,
    'functions.confirm.confirmText': `சரி`,
    'functions.prompt.cancelText': `ரத்து`,
    'functions.prompt.confirmText': `சரி`,
};
