// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `Graag overeenkomen met het gevraagde formaat.`,
    'functions.alert.confirmText': `OK`,
    'functions.confirm.cancelText': `Annuleren`,
    'functions.confirm.confirmText': `OK`,
    'functions.prompt.cancelText': `Annuleren`,
    'functions.prompt.confirmText': `OK`,
};
