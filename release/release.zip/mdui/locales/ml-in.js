// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `ദയവായി അനുഗ്രഹിക്കുക, അഭ്യർത്ഥിച്ച ഫോർമാറ്റ് പൊരുതുക.`,
    'functions.alert.confirmText': `ശരി`,
    'functions.confirm.cancelText': `റദ്ദാക്കുക`,
    'functions.confirm.confirmText': `ശരി`,
    'functions.prompt.cancelText': `റദ്ദാക്കുക`,
    'functions.prompt.confirmText': `ശരി`,
};
