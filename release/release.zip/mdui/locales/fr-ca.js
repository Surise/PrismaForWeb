// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `Veuillez respecter le format demandé.`,
    'functions.alert.confirmText': `D'accord`,
    'functions.confirm.cancelText': `Annuler`,
    'functions.confirm.confirmText': `D'accord`,
    'functions.prompt.cancelText': `Annuler`,
    'functions.prompt.confirmText': `D'accord`,
};
