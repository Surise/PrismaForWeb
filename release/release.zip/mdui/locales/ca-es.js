// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `Si us plau, compleix el format sol·licitat.`,
    'functions.alert.confirmText': `D'acord`,
    'functions.confirm.cancelText': `Cancel·lar`,
    'functions.confirm.confirmText': `D'acord`,
    'functions.prompt.cancelText': `Cancel·lar`,
    'functions.prompt.confirmText': `D'acord`,
};
