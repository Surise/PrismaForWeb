// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `براہ کرم درخواست شدہ فارمیٹ میں موافق ہوں۔`,
    'functions.alert.confirmText': `ٹھیک ہے`,
    'functions.confirm.cancelText': `منسوخ کریں`,
    'functions.confirm.confirmText': `ٹھیک ہے`,
    'functions.prompt.cancelText': `منسوخ کریں`,
    'functions.prompt.confirmText': `ٹھیک ہے`,
};
