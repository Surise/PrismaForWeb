// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `Vui lòng phù hợp với định dạng yêu cầu.`,
    'functions.alert.confirmText': `Đồng ý`,
    'functions.confirm.cancelText': `Hủy`,
    'functions.confirm.confirmText': `Đồng ý`,
    'functions.prompt.cancelText': `Hủy`,
    'functions.prompt.confirmText': `Đồng ý`,
};
