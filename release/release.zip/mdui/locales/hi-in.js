// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `कृपया अनुरोधित स्वरूप को मेल खाएँ।`,
    'functions.alert.confirmText': `ठीक है`,
    'functions.confirm.cancelText': `रद्द करें`,
    'functions.confirm.confirmText': `ठीक है`,
    'functions.prompt.cancelText': `रद्द करें`,
    'functions.prompt.confirmText': `ठीक है`,
};
