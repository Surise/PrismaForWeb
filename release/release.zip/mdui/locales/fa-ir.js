// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `لطفاً به فرمت درخواست شده مطابقت دهید.`,
    'functions.alert.confirmText': `تایید`,
    'functions.confirm.cancelText': `لغو`,
    'functions.confirm.confirmText': `تایید`,
    'functions.prompt.cancelText': `لغو`,
    'functions.prompt.confirmText': `تایید`,
};
