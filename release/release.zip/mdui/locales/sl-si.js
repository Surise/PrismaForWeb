// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `Prosimo, ujemite zahtevani format.`,
    'functions.alert.confirmText': `V redu`,
    'functions.confirm.cancelText': `Prekliči`,
    'functions.confirm.confirmText': `V redu`,
    'functions.prompt.cancelText': `Prekliči`,
    'functions.prompt.confirmText': `V redu`,
};
