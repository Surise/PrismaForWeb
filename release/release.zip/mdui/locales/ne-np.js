// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `कृपया अनुरोधित स्वरूपको मेल खाली जानुहोस्।`,
    'functions.alert.confirmText': `ठिक छ`,
    'functions.confirm.cancelText': `रद्द गर्नुहोस्`,
    'functions.confirm.confirmText': `ठिक छ`,
    'functions.prompt.cancelText': `रद्द गर्नुहोस्`,
    'functions.prompt.confirmText': `ठिक छ`,
};
