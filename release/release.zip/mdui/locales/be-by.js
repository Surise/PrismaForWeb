// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `Калі ласка, адпавядайце патрабаванаму фармату.`,
    'functions.alert.confirmText': `Добра`,
    'functions.confirm.cancelText': `Адмяніць`,
    'functions.confirm.confirmText': `Добра`,
    'functions.prompt.cancelText': `Адмяніць`,
    'functions.prompt.confirmText': `Добра`,
};
