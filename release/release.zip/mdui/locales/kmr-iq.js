// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `تکایە یەکخستنەوە لەگەڵ فۆرماتی داواکراو.`,
    'functions.alert.confirmText': `باشە`,
    'functions.confirm.cancelText': `هەڵوەشاندنەوە`,
    'functions.confirm.confirmText': `باشە`,
    'functions.prompt.cancelText': `هەڵوەشاندنەوە`,
    'functions.prompt.confirmText': `باشە`,
};
