// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `요청된 형식과 일치시켜 주세요.`,
    'functions.alert.confirmText': `확인`,
    'functions.confirm.cancelText': `취소`,
    'functions.confirm.confirmText': `확인`,
    'functions.prompt.cancelText': `취소`,
    'functions.prompt.confirmText': `확인`,
};
