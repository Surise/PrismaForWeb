// Do not modify this file by hand!
// Re-generate this file by running lit-localize
/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
export const templates = {
    'components.textField.patternError': `Palun vastake nõutud formaadiga.`,
    'functions.alert.confirmText': `OK`,
    'functions.confirm.cancelText': `Loobu`,
    'functions.confirm.confirmText': `OK`,
    'functions.prompt.cancelText': `Loobu`,
    'functions.prompt.confirmText': `OK`,
};
