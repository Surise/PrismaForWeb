export { throttle } from '@mdui/shared/helpers/throttle.js';
