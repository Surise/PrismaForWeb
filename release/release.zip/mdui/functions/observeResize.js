export { observeResize } from '@mdui/shared/helpers/observeResize.js';
