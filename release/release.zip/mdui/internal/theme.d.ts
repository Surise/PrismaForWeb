export type Theme = 'light' | 'dark' | 'auto';
