export declare const segmentedButtonGroupStyle: import("lit").CSSResult;
