export declare const segmentedButtonStyle: import("lit").CSSResult;
