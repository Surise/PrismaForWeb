export declare const listStyle: import("lit").CSSResult;
