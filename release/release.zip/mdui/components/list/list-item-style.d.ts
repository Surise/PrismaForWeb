export declare const listItemStyle: import("lit").CSSResult;
