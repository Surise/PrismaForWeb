export declare const listSubheaderStyle: import("lit").CSSResult;
