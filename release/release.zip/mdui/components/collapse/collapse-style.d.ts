export declare const collapseStyle: import("lit").CSSResult;
