export declare const collapseItemStyle: import("lit").CSSResult;
