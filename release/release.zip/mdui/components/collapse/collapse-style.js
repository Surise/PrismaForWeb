import { css } from 'lit';
export const collapseStyle = css `:host{display:block}`;
