export declare const radioStyle: import("lit").CSSResult;
