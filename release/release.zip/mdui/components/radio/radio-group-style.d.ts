export declare const radioGroupStyle: import("lit").CSSResult;
