export declare const tabsStyle: import("lit").CSSResult;
