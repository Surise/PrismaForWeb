export declare const tabStyle: import("lit").CSSResult;
