export declare const tabPanelStyle: import("lit").CSSResult;
