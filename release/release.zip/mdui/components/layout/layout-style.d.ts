export declare const layoutStyle: import("lit").CSSResult;
