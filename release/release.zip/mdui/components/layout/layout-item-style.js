import { css } from 'lit';
export const layoutItemStyle = css `:host{display:flex;z-index:1}`;
