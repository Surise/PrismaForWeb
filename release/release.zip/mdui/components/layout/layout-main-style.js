import { css } from 'lit';
export const layoutMainStyle = css `:host{flex:1 0 auto;max-width:100%;overflow:auto}`;
