export declare const layoutItemStyle: import("lit").CSSResult;
