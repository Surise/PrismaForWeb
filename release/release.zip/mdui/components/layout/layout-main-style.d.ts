export declare const layoutMainStyle: import("lit").CSSResult;
