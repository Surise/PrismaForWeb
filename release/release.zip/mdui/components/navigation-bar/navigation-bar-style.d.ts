export declare const navigationBarStyle: import("lit").CSSResult;
