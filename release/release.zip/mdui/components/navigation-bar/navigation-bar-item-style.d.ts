export declare const navigationBarItemStyle: import("lit").CSSResult;
