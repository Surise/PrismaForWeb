export declare const style: import("lit").CSSResult;
