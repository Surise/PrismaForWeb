export declare const menuItemStyle: import("lit").CSSResult;
