export declare const menuStyle: import("lit").CSSResult;
