export declare const buttonBaseStyle: import("lit").CSSResult;
