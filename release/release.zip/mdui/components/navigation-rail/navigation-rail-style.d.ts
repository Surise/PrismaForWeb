export declare const navigationRailStyle: import("lit").CSSResult;
