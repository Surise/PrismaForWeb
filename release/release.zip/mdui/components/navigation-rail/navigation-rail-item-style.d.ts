export declare const navigationRailItemStyle: import("lit").CSSResult;
