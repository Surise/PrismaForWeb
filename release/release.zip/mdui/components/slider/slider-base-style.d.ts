export declare const sliderBaseStyle: import("lit").CSSResult;
