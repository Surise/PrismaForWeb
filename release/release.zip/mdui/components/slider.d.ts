export * from './slider/index.js';
