export declare const topAppBarTitleStyle: import("lit").CSSResult;
