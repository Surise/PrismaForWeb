export declare const topAppBarStyle: import("lit").CSSResult;
